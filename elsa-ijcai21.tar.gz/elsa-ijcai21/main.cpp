
#include <stdio.h>
#include "Instance.h"
#include "BacktrackingSearch.h"
#include "Bound.h"
#include "LocalSearch.h"

int main( int argc, char *argv[] )
{
    if( argc < 2 || argc > 9 ) {
	fprintf( stderr, "Usage: search inFile [timeLimit|3600] [partitionBoundMin|20] [partitionBoundMax|26] [localSearchRestartsMin|50] [localSearchRestartsMax|500] [widthPrefixPermute|4] [initialOrderFile]\n" );
	exit( 6 );
    }

    if (argc>=3) BacktrackingSearch::timeLimit = atof(argv[2]);
    else BacktrackingSearch::timeLimit = 3600.0;   // 1 hour
    if (argc>=4) Bound::MAX_ELEM_SMALL = atoi(argv[3]);
    else Bound::MAX_ELEM_SMALL = 20;
    if (argc>=5) Bound::MAX_ELEM_LARGE = atoi(argv[4]);
    else Bound::MAX_ELEM_LARGE = 26;
    if (argc>=6) LocalSearch::nRestartsSmall = atoi(argv[5]);
    else LocalSearch::nRestartsSmall = 50;
    if (argc>=7) LocalSearch::nRestartsLarge = atoi(argv[6]);
    else LocalSearch::nRestartsLarge = 500;
    if (argc>=8) BacktrackingSearch::width = atoi(argv[7]);
    else BacktrackingSearch::width = 4;

    printf( "\n%s:\n", argv[1] );

#ifdef DYNSET
    FILE *fp;
    int n;
    if( (fp = fopen( argv[1], "r" )) == NULL ) {
        fprintf( stderr, "Could not open file %s\n", argv[1]);
        exit( 6 );
    }
    fscanf( fp, "%d\n", &n );
    MAX_VARS = n;
    fclose(fp);
#endif
    Instance instance( argv[1] );

    if (argc>=9) {
    	FILE *fsol;
    	if( (fsol = fopen( argv[8], "r" )) == NULL ) {
    		fprintf( stderr, "Could not open file %s\n", argv[8]);
    		exit( 6 );
    	}
    	instance.initial_ordering = new int[instance.nVars()]();
    	for (int i=0; i<instance.nVars(); i++) {
    		fscanf( fsol, "%d", &instance.initial_ordering[i]);
    	}
    	fclose(fsol);
    }

    BacktrackingSearch btSearch( &instance );

    /*
     *  Find the minimum cost solution and its associated cost.
     */
    int ordering[instance.nVars()];
    int solution[instance.nVars()];
    Score cost;
    btSearch.solve( ordering, solution, &cost );
    //instance.printSolution( ordering, solution, cost );
}

