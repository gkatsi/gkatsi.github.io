# mobs
Code for project. I'll clean up the code and write documentation soon.

Requires boost library
