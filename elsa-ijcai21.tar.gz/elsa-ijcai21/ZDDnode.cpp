#include "ZDDnode.h"
#include "ZDD.h"
#include <algorithm>
#include <cmath>
#include <stdio.h>
#include <cassert>

#include <vector>

ZDDnode::ZDDnode(int i, int id, ZDD* zdd) :
    dashedChild(nullptr),
        solidChild(nullptr),
    sink(false),
        erased(false),
        varIndex(i),
        hasDashedChild(false),
        hasSolidChild(false),
        ID(id),
        theZDD(zdd)
{
}

ZDDnode::~ZDDnode()
{
}

void
ZDDnode::addParent(ZDDnode* parent)
{
        parents.push_back(parent);
}

void
ZDDnode::removeParent(ZDDnode* parent)
{
        for(int p = 0; p < parents.size(); p++){
                if(parents[p]->getID() == parent->getID()){
                        parents.erase(parents.begin()+p);
                        return;
                }
        }
}

void
ZDDnode::transferParentsTo(ZDDnode* node)
{
        for(int p = 0; p < parents.size(); p++){
                ZDDnode* parent = parents[p];
                if(parent->hasFalseChild() && parent->getFalseChildID() == this->ID){
                        parent->setFalseChild(node);
                }
                if(parent->hasTrueChild() && parent->getTrueChildID() == this->ID){
                        parent->setTrueChild(node);
                }
                node->addParent(parent);
                removeParent(node);
        }
}

void
ZDDnode::setFalseChild(ZDDnode* child)
{
        dashedChild = child;
        hasDashedChild = true;
}

void
ZDDnode::setTrueChild(ZDDnode* child)
{
        solidChild = child;
        hasSolidChild = true;
}

void
ZDDnode::removeFalseChild()
{
        dashedChild = nullptr;
        hasDashedChild = false;
}

void
ZDDnode::removeTrueChild()
{
        solidChild = nullptr;
        hasSolidChild = false;
}

void
ZDDnode::removeChild(ZDDnode* child)
{
        if(hasSolidChild && solidChild->getID() == child->getID())
                removeTrueChild();
        if(hasDashedChild && dashedChild->getID() == child->getID())
                removeFalseChild();
}

bool
ZDDnode::checkParents()
{
        //printf("Checking parents of %d (id %d)\n", varIndex, ID);
        if(root)
                return false;
        assert(isErased());
        bool success = true;
        /*if(theZDD->getVarIndex() == 19 && varIndex == 12 && ID == 1201){
                printf("Current set of parents of %d (id %d):\n", varIndex, ID);
                for(int i = 0; i < getParents().size(); i++)
                        printf("#%d %d (id %d)   ",i,getParents()[i]->getVarIndex(),getParents()[i]->getID());
                printf("\n");
        }*/
        for(int i = 0; i < parents.size(); i++){
                //printf("checking parent #%d %d (id %d) of %d (id %d)\n",i,parents[i]->getVarIndex(),parents[i]->getID(),varIndex,ID);
                //assert(parents[i] != nullptr);
                //assert(parents[i]->getVarIndex() >= 0);
                if(parents[i]->getVarIndex() < 0 || parents[i]->getVarIndex() > 30){ // >30 is for flag_BDe
                        printf("\n!!!ERROR!!!\n\n");
                        //theZDD->printNodesByLevels();
                        //printf("\n\nParents:\n");
                        //theZDD->printParentsByLevels();
                }
                //assert(parents[i]->getVarIndex() <= 30);
                if(false && theZDD->getVarIndex() == 19)
                    printf("Remove edge from %d (id %d) to %d (id %d)\n", parents[i]->getVarIndex(), parents[i]->getID(), varIndex, ID);
                parents[i]->removeChild(this);
                if(parents[i]->hasNoChild()){
                        if(false && theZDD->getVarIndex() == 19)
                            printf("Now that %d (id %d) has no child, mark it as erased\n", parents[i]->getVarIndex(), parents[i]->getID());
                        parents[i]->markAsErased();
                        success = success && parents[i]->checkParents();
                }
        }
        parents.clear();
        //printf("RETURN from checking parents of %d (id %d)\n",varIndex,ID);
        return success;
}

bool
ZDDnode::checkChildren()
{
        //printf("Checking children of %d (id %d)\n", varIndex, ID);
        if(sink)
                return false;
        assert(isErased());
        bool success = true;
        if(hasSolidChild){
                solidChild->removeParent(this);
                if(solidChild->hasNoParent()){
                        solidChild->markAsErased();
                        success = success && solidChild->checkChildren();
                }
        }
        if(hasDashedChild){
                dashedChild->removeParent(this);
                if(dashedChild->hasNoParent()){
                        dashedChild->markAsErased();
                        success = success && dashedChild->checkChildren();
                }
        }
        return success;
}
