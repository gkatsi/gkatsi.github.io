#ifndef _ZDD_H_
#define _ZDD_H_

#include "Instance.h"
#include "ZDDnode.h"
#include <vector>
#include <iostream>

#include <boost/functional/hash.hpp>
#include <unordered_map>
#include <memory>
#include <queue>
#include <set>

class ZDD
{
    public:
        ZDD(Instance* instance, int i);
        ~ZDD();

        Set propagateNecessaryParents();

        bool pruneParentSetsContaining(int p);

        int getVarIndex() {return thisVariable;}
        
        void printNodesByLevels();
        
        void printParentsByLevels();
        std::vector< std::vector<ZDDnode*> > nodesAtLevel;

        bool hasValueThatIsSubsetOf(Set precedingVars);

    private:
        Instance* instance;
        ZDDnode* root;
        ZDDnode* sink;
        int thisVariable; //variable for which this ZDD is constructed
        int nextID;
        int nbNodes;
        int width;
        int nbLevels;
        std::vector<int> orderOfVariables;
        //std::vector< std::vector<ZDDnode*> > nodesAtLevel;
        std::vector< int > widthAtLevel;

        void initialize();
        void constructBinaryTree();
        void mergeNodes();
        void findMaxWidth();
        void removeErasedNodes();

        void printParameters();

        void verifyValues();
        int verifyPaths(ZDDnode* node);

        std::unordered_map< int, ZDDnode* > visitedNodes;
        bool reachSinkFromNodeFollowingSubsetOf(ZDDnode* node, Set precedingVars);
};

#endif // _ZDD_H_
