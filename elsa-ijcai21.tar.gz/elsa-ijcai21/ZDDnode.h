#ifndef _ZDDNODE_H_
#define _ZDDNODE_H_

#include <vector>

class ZDD;

class ZDDnode
{
    public:
        ZDDnode(int i, int id, ZDD* zdd);
        ~ZDDnode();

        void setFalseChild(ZDDnode* child);
        void setTrueChild(ZDDnode* child);

        void removeFalseChild();
        void removeTrueChild();
        void removeChild(ZDDnode* child);

        void addParent(ZDDnode* parent);

        void removeParent(ZDDnode* parent);

        void transferParentsTo(ZDDnode* node);

        void setSink() { sink = true; }
        bool isSink() { return sink; }

        void setRoot() { root = true; }
        bool isRoot() { return root; }
        
        void markAsErased() { erased = true; }
        bool isErased() { return erased; }

        ZDDnode* getFalseChild() { return dashedChild; }
        ZDDnode* getTrueChild() { return solidChild; }

        bool hasFalseChild() { return hasDashedChild; }
        bool hasTrueChild() { return hasSolidChild; }

        int getFalseChildID() { return dashedChild->getID(); }
        int getTrueChildID() { return solidChild->getID(); }

        int getFalseChildVarIndex() { return dashedChild->getVarIndex(); }
        int getTrueChildVarIndex() { return solidChild->getVarIndex(); }

        int getID() { return ID; }
        int getVarIndex() { return varIndex; }

        const std::vector<ZDDnode*>& getParents() const { return parents; }

        bool checkParents();
        bool checkChildren();

        bool hasNoChild() { return !( hasFalseChild() || hasTrueChild() ); }
        bool hasNoParent() { return (parents.size() == 0) ? true:false; }

public:
        ZDD* theZDD;
        ZDDnode* dashedChild;
        ZDDnode* solidChild;

        bool hasDashedChild;
        bool hasSolidChild;

        bool sink;
        bool root;
        bool erased;

        std::vector<ZDDnode*> parents;

        int varIndex;
        int ID;
};

#endif // _ZDDNODE_H_
