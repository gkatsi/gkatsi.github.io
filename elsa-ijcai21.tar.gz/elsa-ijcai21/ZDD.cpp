#include "ZDD.h"
#include "ZDDnode.h"
#include "Instance.h"
#include <algorithm>
#include <cmath>
#include <boost/functional/hash.hpp>
#include <unordered_map>
#include <memory>
#include <queue>
#include <set>
#include <cassert>
#include <fstream>
#include <inttypes.h>
#include <stack>
#include <random>

#include <iostream>
#include <utility>

typedef std::pair<int,int> pair;

struct pair_hash
{
    template <class T1, class T2>
    std::size_t operator() (const std::pair<T1, T2> &pair) const
    {
        return std::hash<T1>()(pair.first) ^ std::hash<T2>()(pair.second);
    }
};

/*
 *  Constructor for cluster cut.
 */
ZDD::ZDD(Instance* i, int j) :
    instance(i),
        thisVariable(j),
        nbNodes(0),
        width(0),
        nextID(2),
        nbLevels(i->nVars()),
        root(nullptr)
{
        for( int i = 0; i < instance->nVars(); i++ ){
                if(i != j)
                        orderOfVariables.push_back(i);
        nodesAtLevel.push_back( std::vector<ZDDnode*>() );
                widthAtLevel.push_back(0);
        }

    //unsigned seed = 0;
    //std::shuffle(orderOfVariables.begin(), orderOfVariables.end(), std::default_random_engine(seed));

        root = new ZDDnode(orderOfVariables[0], 0, this);
        root->setRoot();
        nodesAtLevel[0].push_back(root);
        widthAtLevel[0]++;

        sink = new ZDDnode(-1, 1, this);
        sink->setSink();
        nodesAtLevel[nbLevels-1].push_back(sink);
        widthAtLevel[nbLevels-1]++;

        initialize();
}

ZDD::~ZDD()
{
}

void
ZDD::initialize()
{
        constructBinaryTree();
        //printParameters();
        //printNodesByLevels();
        mergeNodes();
        removeErasedNodes();
        findMaxWidth();
        verifyValues();
        assert(verifyPaths(root) == instance->getDomainSizeP(thisVariable));
        //propagateNecessaryParents();
}

void
ZDD::constructBinaryTree()
{
        for(int a = 0; a < instance->getDomainSizeP(thisVariable); a++){
                Set value = instance->getParentSet(thisVariable, a);
                ZDDnode* currentNode = root;
                assert(currentNode != nullptr);
                for(int level = 0; level < nbLevels-1; level++){
                        if(element_of(currentNode->getVarIndex(), value)){
                                if(currentNode->hasTrueChild()){
                                        assert(currentNode->getTrueChild() != nullptr);
                                        currentNode = currentNode->getTrueChild();
                                        continue;
                                }
                                if(level < nbLevels-2){
                                        currentNode->setTrueChild(new ZDDnode(orderOfVariables[level+1], nextID, this));
                                        assert(currentNode->getTrueChild() != nullptr);
                                        (currentNode->getTrueChild())->addParent(currentNode);
                                        currentNode = currentNode->getTrueChild();
                                        nextID++;
                                        nbNodes++;
                                        nodesAtLevel[level+1].push_back(currentNode);
                                        widthAtLevel[level+1]++;
                                }
                                else{
                                        currentNode->setTrueChild(this->sink);
                                        assert(currentNode->getTrueChild() != nullptr);
                                        sink->addParent(currentNode);
                                }
                        }
                        else{
                                if(currentNode->hasFalseChild()){
                                        assert(currentNode->getFalseChild() != nullptr);
                                        currentNode = currentNode->getFalseChild();
                                        continue;
                                }
                                if(level < nbLevels-2){
                                        currentNode->setFalseChild(new ZDDnode(orderOfVariables[level+1], nextID, this));
                                        assert(currentNode->getFalseChild() != nullptr);
                                        (currentNode->getFalseChild())->addParent(currentNode);
                                        currentNode = currentNode->getFalseChild();
                                        nextID++;
                                        nbNodes++;
                                        nodesAtLevel[level+1].push_back(currentNode);
                                        widthAtLevel[level+1]++;
                                }
                                else{
                                        currentNode->setFalseChild(this->sink);
                                        assert(currentNode->getFalseChild() != nullptr);
                                        sink->addParent(currentNode);
                                }
                        }
                }
        }
}

void
ZDD::mergeNodes()
{
        //using cache_element = std::vector<int>; //lookup key is a vector [falseChildID, trueChildID]

        for(int i = nbLevels-1; i >= 0; i--) if(nodesAtLevel[i].size() > 1){

                //std::unordered_map<std::shared_ptr<cache_element>, ZDDnode* > nodesAtCurrentLevel;
                std::unordered_map< pair, ZDDnode*, pair_hash > nodesAtCurrentLevel;

                for(int j = 0; j < nodesAtLevel[i].size(); j++){

                        ZDDnode* currentNode = nodesAtLevel[i][j];
                        std::pair<int, int> key = std::pair<int, int>(); //lookup key is a pair <falseChildID, trueChildID>

                        if(currentNode->hasFalseChild()){
                                assert(currentNode->getFalseChild() != nullptr);
                                //(*key).push_back(currentNode->getFalseChildVarIndex());
                                //key.first = currentNode->getFalseChildVarIndex();
                                key.first = currentNode->getFalseChildID();
                        }
                        else{
                                //(*key).push_back(-1);
                                key.first = -1;
                        }
                        if(currentNode->hasTrueChild()){
                                assert(currentNode->getTrueChild() != nullptr);
                                //(*key).push_back(currentNode->getTrueChildVarIndex());
                                //key.second = currentNode->getTrueChildVarIndex();
                                key.second = currentNode->getTrueChildID();
                        }
                        else{
                                //(*key).push_back(-1);
                                key.second = -1;
                        }

                        auto got = nodesAtCurrentLevel.find (key);

                        if (got != nodesAtCurrentLevel.end() ){
                                if(false && thisVariable == 11)
                                        printf("Merging node %d_%d into node %d_%d\n",
                                                        currentNode->getVarIndex(),currentNode->getID(),
                                                        nodesAtCurrentLevel[key]->getVarIndex(),nodesAtCurrentLevel[key]->getID());
                                currentNode->markAsErased();
                                widthAtLevel[i]--;
                                nbNodes--;
                                currentNode->transferParentsTo(nodesAtCurrentLevel[key]);
                        }

                        else{
                                nodesAtCurrentLevel.insert_or_assign(key, currentNode);
                        }
                }
        }
}

void
ZDD::removeErasedNodes()
{
        for(int i = nbLevels - 1; i > 0; --i){
            bool nodeRemoved = true;
            for(ZDDnode *n : nodesAtLevel[i]) {
                auto pend = remove_if(n->parents.begin(), n->parents.end(),
                                      [&](ZDDnode *p) { return p->isErased(); });
                n->parents.erase(pend, n->parents.end());
            }

            auto newend = remove_if(nodesAtLevel[i].begin(), nodesAtLevel[i].end(), [&](ZDDnode* node) {
                if (node->isErased()) {
                    delete node;
                    return true;
                }
                return false;
            });
            nodesAtLevel[i].erase(newend, nodesAtLevel[i].end());

        }
}

void
ZDD::findMaxWidth()
{
        for(int i = 0; i < nbLevels; i++){
                if(widthAtLevel[i] > width)
                        width = widthAtLevel[i];
        }
}

void
ZDD::printParameters()
{
        //printf("ZDD for variable %d\n", thisVariable);
        //printf("Number of nodes is %d\n", nbNodes);
        //printf("Number of levels is %d\n", nbLevels);
        //printf("Maximum width is %d\n", width);
        printf("%d %d %d \n", instance->getDomainSizeP(thisVariable), nbNodes, width);
}

void
ZDD::printNodesByLevels()
{
        for(int i = 0; i < nbLevels; i++){
                printf("Level %d: ", i);
                for(int j = 0; j < nodesAtLevel[i].size(); j++) if(!nodesAtLevel[i][j]->isErased()){
                        printf("%d (%d) [ ", nodesAtLevel[i][j]->getID(), nodesAtLevel[i][j]->getVarIndex());

                        if(nodesAtLevel[i][j]->hasFalseChild()){
                                assert(nodesAtLevel[i][j]->getFalseChild() != nullptr);
                                printf("%d ", nodesAtLevel[i][j]->getFalseChildID());
                        }
                        else{
                                printf("-1 ");
                        }
                        if(nodesAtLevel[i][j]->hasTrueChild()){
                                assert(nodesAtLevel[i][j]->getTrueChild() != nullptr);
                                printf("%d ", nodesAtLevel[i][j]->getTrueChildID());
                        }
                        else{
                                printf("-1 ");
                        }

                        printf("]   ");

                }
                printf("\n");
        }
        printf("\n");
}

void
ZDD::printParentsByLevels()
{
        for(int i = 0; i < nbLevels; i++){
                printf("Level %d: ", i);
                for(int j = 0; j < nodesAtLevel[i].size(); j++){
                        if(nodesAtLevel[i][j]->isErased())
                                printf("**");
                        printf("%d (%d) { ", nodesAtLevel[i][j]->getID(), nodesAtLevel[i][j]->getVarIndex());

                        for(int p = 0; p < nodesAtLevel[i][j]->getParents().size(); p++){
                                ZDDnode* parent = nodesAtLevel[i][j]->getParents()[p];
                                if(parent->hasFalseChild() && parent->getFalseChildID() == nodesAtLevel[i][j]->getID())
                                        printf("F %d (%d) ", parent->getID(), parent->getVarIndex());
                                if(parent->hasTrueChild() && parent->getTrueChildID() == nodesAtLevel[i][j]->getID())
                                        printf("T %d (%d) ", parent->getID(), parent->getVarIndex());
                        }

                        printf("}");

                }
                printf("\n");
        }
        printf("\n");
}

void
ZDD::verifyValues()
{
        for(int a = 0; a < instance->getDomainSizeP(thisVariable); a++){
                Set value = instance->getParentSet(thisVariable, a);
                ZDDnode* currentNode = root;
                assert(currentNode != nullptr);
                for(int level = 0; level < nbLevels-1; level++){
                        if(element_of(currentNode->getVarIndex(), value)){
                                assert(currentNode->getTrueChild() != nullptr);
                                currentNode = currentNode->getTrueChild();
                                continue;
                        }
                        else{
                                assert(currentNode->getFalseChild() != nullptr);
                                currentNode = currentNode->getFalseChild();
                                continue;
                        }
                }
                assert(currentNode->getVarIndex() == -1);
        }
}

int
ZDD::verifyPaths(ZDDnode* node)
{
        if(node->isSink())
                return 1;

        int falseCount = 0;
        int trueCount = 0;

        if(node->hasFalseChild())
                falseCount = verifyPaths(node->getFalseChild());
        if(node->hasTrueChild())
                trueCount = verifyPaths(node->getTrueChild());

        return trueCount + falseCount;
}

Set
ZDD::propagateNecessaryParents()
{
        Set necessaryParents = emptySet;

        for(int l = 0; l < nbLevels-1; l++){
                bool isNecessary = true;
                for(int i = 0; i < nodesAtLevel[l].size(); i++){
                        if(nodesAtLevel[l][i]->hasFalseChild())
                                isNecessary = false;
                }
                if(isNecessary){
                        int necessaryParent = nodesAtLevel[l][0]->getVarIndex();
                        add_element(necessaryParent, necessaryParents);
                        //printf("%d is a necessary parent of %d\n",necessaryParent,thisVariable);
                        (instance->getZDDofVariable(necessaryParent))->pruneParentSetsContaining(thisVariable);
                }
        }
        return necessaryParents;
}

bool
ZDD::pruneParentSetsContaining(int p)
{
        //printf("Pruning all values from variable %d containing variable %d\n", thisVariable, p);
        int theLevel;
        for(int l = 0; l < nbLevels; l++){
                if(nodesAtLevel[l][0]->getVarIndex() == p){
                        theLevel = l;
                        break;
                }
        }

        assert(nodesAtLevel[theLevel][0]->getVarIndex() ==p);
        bool success = true;

        for(int i = 0; i < nodesAtLevel[theLevel].size(); i++){
                ZDDnode* theNode = nodesAtLevel[theLevel][i];
                if(false && thisVariable == 19)
                        printParentsByLevels();
                if(false && thisVariable == 19 && p == 27)
                        printf("theNode = %d number #%d (id %d)\n",theNode->getVarIndex(),i,theNode->getID());
                if(theNode->hasTrueChild()){
                        assert(theNode->getTrueChild() != nullptr);

                        ZDDnode* trueChild = theNode->getTrueChild();

                        theNode->removeTrueChild();
                        if(theNode->hasNoChild()){
                                if(false && thisVariable == 19 && p == 27)
                                    printf("Now that %d (id %d) has no child, mark it as erased\n", theNode->getVarIndex(), theNode->getID());
                                //assert(theNode->getFalseChild() != nullptr);
                                theNode->markAsErased();
                                success = success && theNode->checkParents();
                        }

                        trueChild->removeParent(theNode);
                        if(trueChild->hasNoParent()){
                                if(false && thisVariable == 19 && p == 27)
                                    printf("Now that %d (id %d) has no parent, mark it as erased\n", trueChild->getVarIndex(), trueChild->getID());
                                trueChild->markAsErased();
                                success = success && trueChild->checkChildren();
                        }
                }
        }
        removeErasedNodes();
        //printNodesByLevels();
        //if(!success)
                //printf("DOMAIN WIPE-OUT\n");
        return success;
}

bool
ZDD::hasValueThatIsSubsetOf(Set precedingVars)
{
        visitedNodes.clear();

        return reachSinkFromNodeFollowingSubsetOf(root, precedingVars);
}

bool
ZDD::reachSinkFromNodeFollowingSubsetOf(ZDDnode* node, Set precedingVars)
{
        if(node->isSink())
                return true;

        bool sinkReached = false;

        if(element_of(node->getVarIndex(), precedingVars)){

                bool trueChildVisitedOrNonExistent = false;
                bool falseChildVisitedOrNonExistent = false;

                if(node->hasTrueChild()){
                        auto gotTrue = visitedNodes.find ((node->getTrueChild())->getID());
                        if (gotTrue != visitedNodes.end() ){
                                trueChildVisitedOrNonExistent = true;
                        }
                        else{
                                sinkReached = sinkReached || reachSinkFromNodeFollowingSubsetOf(node->getTrueChild(), precedingVars);
                                if(sinkReached)
                                        return true;
                        }
                }
                else{
                        trueChildVisitedOrNonExistent = true;
                }

                if(node->hasFalseChild()){
                        auto gotFalse = visitedNodes.find ((node->getFalseChild())->getID());
                        if (gotFalse != visitedNodes.end() ){
                                falseChildVisitedOrNonExistent = true;
                        }
                        else{
                                sinkReached = sinkReached || reachSinkFromNodeFollowingSubsetOf(node->getFalseChild(), precedingVars);
                        }
                }
                else{
                        falseChildVisitedOrNonExistent = true;
                }

                if(trueChildVisitedOrNonExistent && falseChildVisitedOrNonExistent){
                        visitedNodes.insert_or_assign(node->getID(), node);
                        return false;
                }
        }

        else{
                if(node->hasFalseChild()){
                        auto got = visitedNodes.find ((node->getFalseChild())->getID());
                        if (got != visitedNodes.end() ){
                                visitedNodes.insert_or_assign(node->getID(), node);
                                return false;
                        }
                        sinkReached = reachSinkFromNodeFollowingSubsetOf(node->getFalseChild(), precedingVars);
                }
                else{
                        visitedNodes.insert_or_assign(node->getID(), node);
                        return false;
                }
        }

        visitedNodes.insert_or_assign(node->getID(), node);

        return sinkReached;
}