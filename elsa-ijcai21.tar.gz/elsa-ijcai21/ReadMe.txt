------------------------------------------------------------------------------
Exact Learning of bayesian network Structure using Acyclicity reasoning (ELSA)
------------------------------------------------------------------------------
See
Fulya Trösser, Simon de Givry, and George Katsirelos
Improved acyclicity reasoning for bayesian network structure learning
In Proc. of IJCAI-21, Montreal, Canada, 2021

This software is based on CPBayes [van Beek and Hoffmann, CP 2015]. Many thanks to them!

On linux, compile using a recent C++ compiler (g++-8 or above) and CMake:

>cmake .
>make

It produces several internal branch-and-bound solvers for different maximum problem sizes (number of Bayesian network variables) 

and also one local search solver in mobs-minobs directory

which are used by the main solver called elsa.

Command line parameters for the elsa solver are given by

>./elsa -h

Try for instance, running MINOBS local search method during 30 seconds followed by a branch-and-bound complete search method. 

>unxz ./kdd.test.jkl.xz ; ./elsa -m 30 -B 20 ./kdd.test.jkl

For the experimental results reported in the IJCAI'21 paper, use the following options if there are less than or equal to 64 random variables (e.g. kdd.test):

>./elsa -m 0 -b 20 -B 26 -r 50 -R 500 -w 4 -t 3600 ./kdd.test.jkl

or else greater than 64 random variables (e.g. plants.test):

>./elsa -m 0 -b 20 -B 20 -r 15 -R 30 -w 4 -t 36000 ./plants.test.jkl

