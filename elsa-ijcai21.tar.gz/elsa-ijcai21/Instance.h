/*
 *  Instance: An instance of the combinatorial optimization problem
 *            for learning a Bayesian network from data.
 */
#ifndef _INSTANCE_H_
#define _INSTANCE_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <vector>
#include <set>
#include <bitset>
#include <functional>

// update value (parent variable) ordering at each best solution (DAG) found (aka solution phase saving) and restart
#define RESTART

#define VERBOSE 0

//#define COLORS

//fonts color
#ifdef COLORS
#define FBLACK      "\033[0;30m"
#define FRED        "\033[0;31m"
#define FGREEN      "\033[0;32m"
#define FYELLOW     "\033[0;33m"
#define FBLUE       "\033[0;34m"
#define FPURPLE     "\033[0;35m"
#define FNONE       "\033[0m"
#else
#define FBLACK      ""
#define FRED        ""
#define FGREEN      ""
#define FYELLOW     ""
#define FBLUE       ""
#define FPURPLE     ""
#define FNONE       ""
#endif

/*
 *  Definitions for scores.
 *
 *  Defines are in case the type definition changes.
 *  Using floats or doubles instead is possible but
 *  testing equality or even less than is problemetic.
 *  Would need something along these lines:
 *      static const double epsilon = 1.0e-05;
 *      #define lessThan(a,b) ((a - b) < -epsilon)
 */
typedef int64_t Score;
inline constexpr bool gt(Score a, Score b) { return a > b; }
inline constexpr bool ge(Score a, Score b) { return a >= b; }
inline constexpr bool lt(Score a, Score b) { return a < b; }
inline constexpr bool le(Score a, Score b) { return a <= b; }
static const Score MAX_SCORE = 9223372036854775807LL;// larger than any possible score
static const double scale = 100000.0;   // 5 digits of precision
static const int precision = 5;         // 5 digits of precision

/*
 *  Definitions for parent sets.
 */

// choose one of these implementation
//#define SET32
//#define SET64
//#define SET128
//#define BITSET 192
//#define DYNSET

#ifdef SET32
typedef uint32_t Set;
#define set_empty(s) (s == 0)
#define complement(s) (~s)
#define add_element(e,s) (s |= ((Set)1 << e))
#define remove_element(e,s) (s ^= ((Set)1 << e))
#define element_of(e,s) (s & ((Set)1 << e))
#define subset_of(s,t) ((s & t) == s)
#define intersection(s,t) (s & t)
#define union(s,t) (s | t)
#define set_equal(s,t) (s == t)
#define emptySet     ((Set)0x00000000)
#define universalSet ((Set)0xFFFFFFFF)
static const int MAX_VARS = 32; // sizeof(Set)
#endif

#ifdef SET64
typedef uint64_t Set;
#define set_empty(s) (s == 0)
#define complement(s) (~s)
#define add_element(e,s) (s |= ((Set)1 << e))
#define remove_element(e,s) (s ^= ((Set)1 << e))
#define element_of(e,s) (s & ((Set)1 << e))
#define subset_of(s,t) ((s & t) == s)
#define intersection(s,t) (s & t)
#define union(s,t) (s | t)
#define set_equal(s,t) (s == t)
#define emptySet ((Set)0x0000000000000000)
#define universalSet ((Set)0xFFFFFFFFFFFFFFFF)
static const int MAX_VARS = 64; // sizeof(Set)
#endif

#ifdef SET128
typedef unsigned __int128 Set;
#define set_empty(s) (s == 0)
#define complement(s) (~s)
#define add_element(e,s) (s |= ((Set)1 << e))
#define remove_element(e,s) (s ^= ((Set)1 << e))
#define element_of(e,s) (s & ((Set)1 << e))
#define subset_of(s,t) ((s & t) == s)
#define intersection(s,t) (s & t)
#define union(s,t) (s | t)
#define set_equal(s,t) (s == t)
#define emptySet ((Set)0)
#define universalSet (complement(emptySet))
static const int MAX_VARS = 128; // sizeof(Set)
#endif

#ifdef BITSET
typedef std::bitset<BITSET> Set;
#define set_empty(s) ((s).none())
#define complement(s) (~s)
#define add_element(e,s) ((s).set(e))
#define remove_element(e,s) ((s).reset(e))
#define element_of(e,s) ((s).test(e))
#define subset_of(s,t) ((s & t) == s)
#define intersection(s,t) (s & t)
#define union(s,t) (s | t)
#define set_equal(s,t) (s == t)
#define emptySet (Set())
#define universalSet (complement(emptySet))
static const int MAX_VARS = BITSET; // sizeof(Set)
#endif

#ifdef DYNSET
#include <boost/dynamic_bitset.hpp>
typedef boost::dynamic_bitset<uint64_t> Set;
#define set_empty(s) ((s).none())
#define complement(s) (~s)
#define add_element(e,s) ((s).set(e))
#define remove_element(e,s) ((s).reset(e))
#define element_of(e,s) ((s).test(e))
#define subset_of(s,t) ((s & t) == s)
#define intersection(s,t) (s & t)
#define union(s,t) (s | t)
#define set_equal(s,t) (s == t)
#define emptySet (Set(MAX_VARS))
#define universalSet (complement(emptySet))
static int MAX_VARS = 0;
#endif

//needed for Pattern database memory addresses
typedef uint64_t Set64;
#define set_empty64(s) (s == 0)
#define complement64(s) (~s)
#define add_element64(e,s) (s |= ((Set64)1 << e))
#define remove_element64(e,s) (s ^= ((Set64)1 << e))
#define element_of64(e,s) (s & ((Set64)1 << e))
#define subset_of64(s,t) ((s & t) == s)
#define intersection64(s,t) (s & t)
#define union64(s,t) (s | t)
#define set_equal64(s,t) (s == t)
#define emptySet64     ((Set64)0x0000000000000000)
#define universalSet64 ((Set64)0xFFFFFFFFFFFFFFFF)

class Graph;

class ZDD;

using domain = std::vector<int>;

class Instance
{
public:
        Instance( char *fileName );
        ~Instance();

        /*
         *  Number of random variables in instance.
         */
        int nVars() const;

        /*
         *  Domain size of
         *      parent variable v,
         *      ordering variable v,
         *      depth variable v.
         */
        int getDomainSizeP( int v ) const;
        int getDomainSizeO( int v ) const;
        int getDomainSizeD( int v ) const;

        /*
         *  Current domain size of
         *      parent variable v,
         *      ordering variable v,
         *      depth variable v.
         */
        int getCurrentDomainSizeP( int v ) const;
        int getCurrentDomainSizeO( int v ) const;
        int getCurrentDomainSizeD( int v ) const;
        int getLastValidP( int v ) const;

        /*
         *  Name of instance.
         */
        const char *benchmarkName() const;

        /*
         *  Determine the minimum cost subnetwork (solution) and its cost
         *  for the ordering, given the ancestors.
         */
        Score minCostOrdering( Set ancestors,
                int *ordering, int m, int *solution = NULL );

        /*
         *  Determine the parent set for the variable v that has the
         *  minimum cost given v that comes next in the ordering;
         *  i.e., all parents of v must be in the ordering or in the
         *  set of ancestors.
         */
        int getMinCostParentSet( int *ordering, int m, int v );
        int getMinCostParentSet( Set ancestors, int v );

        /*
         *  Determine the depth of the parent set a for the variable v given
         *  that v comes next in the ordering; i.e., all parents a of v will
         *  exist in the ordering. Ordering is valid for ordering[0..m-1].
         */
        int getDepthParentSet(
                int *ordering, int *depth, int m, int v, int a );
        int getDepthParentSetUnordered(
                int *ordering, int *depth, int m, int v, int a );

        /*
         *  Given parents set a of variable v, determine whether there
         *  exists a parent set b that is of lower cost and is contained
         *  in the induced parent set of a; i.e., where it is known that
         *  all of the variables in the ordering precede variable v.
         *
         */
        bool containedInIP( int *ordering, int m, int v, int a );
        bool containedInIP_condensed( int *ordering, int m, int v,
                                      const domain& dom, size_t idx );

        /*
         *  Return the cost of domain element a of parent variable v.
         */
        Score getCost( int v, int a );

        /*
         *  Determine whether x = a and y = b form a covered edge;
         *  i.e., x = P and y = (P union { x }).
         *  Determine whether y = b and z = c form a covered edge;
         *  if the covered edge x --> y is flipped to be y --> x.
         */
        bool coveredEdge( int x, int a, int y, int b );
        bool flippedCoveredEdge( int x, int a, int y, int b, int z, int c );
        bool triangleCoveredEdge(
                int w, int a,
                int x, int b,
                int y, int c,
                int z, int d );

        /*
         *  Print the parent set of element a of variable v.
         */
        void printParentSet( int v, int a );

        /*
         *  Print a solution.
         */
        void printSolution( int *ordering, int *solution, Score cost );
        void writeSolution( FILE *fp, int *ordering, int *solution, Score cost );

        /*
         *  Routines for querying and setting whether domain element a of
         *  variable v is valid. A value of -1 indicates valid;
         *  0, ..., n-1 indicate the element was removed at that level
         *  in the search.
         */
        bool validP( int v, int a );
        bool validO( int v, int a );
        bool validD( int v, int a );
        int  getValidP( int v, int a );
        int  getValidO( int v, int a );
        int  getValidD( int v, int a );
        void setValidP( int v, int a, int value );
        void setValidO( int v, int a, int value );
        void setValidD( int v, int a, int value );

        const domain& getDomainP(int v);

        /*
         *  Determine set of necessary parents of vertices.
         *  Determine set of necessary edges for vertices.
         */
        void findNecessaryParents();
        void findNecessaryParents( int w );
        Set necessaryEdges( int v );
        Set getParentSet( int v, int a );

        ZDD* getZDDofVariable(int v) { return ZDDdomainP[v]; }
        void reinitializeZDDs();
        void createZDDs();

        /*
         *  Update parents sets given that parent variables
         *  v and w are symmetric.
         */
        void symmetricParentVariables( int v, int w );

        /*
         *  Add all or just the top few parent sets as
         *  edges in the graph.
         */
        void addEdges( Graph *graph );
        void addEdges( Graph *graph, int top );
        void addEdges( Graph *graph, bool *instantiated );


        /*
         *  Debugging.
         */
        void dumpInstance();
        void dumpState(
            int currentLevel,
            int *currentParents,
            int *currentOrdering,
            int *currentDepth,
            bool *instantiatedP );
        void dumpStateFull(
            int currentLevel,
            int *currentParents,
            int *currentOrdering,
            int *currentDepth,
            bool *instantiatedP );
        void dumpDebug(
            bool *instantiatedP,
            std::vector< std::vector<Score> > deltaCost,
            Set variables );

        int *initial_ordering{NULL};

    private:
        void initialize( char *fileName );
        char benchmark[128];

        /*
         *  Structure of a domain value: The parent set, the cost
         *  of this parent set, and whether the domain value is valid;
         *  i.e., has not been pruned away by constraint propagation.
         */
        typedef struct {
            Score  cost;
            Set    parentSet;
            int    cardinality;
            int    valid;
        } Value;

        static int compare( const void *a, const void *b );

        /*
         *  Constraint model.
         */
        int n;                          // number of random variables
        std::vector<ZDD*> ZDDdomainP;   // ZDD domain of parent variables
#ifdef DYNSET
        int *domainSizeP;      // domain size of parent variables
        Value **domainP;       // domain of parent variables
        int *domainSizeO;      // domain size of ordering variables
        int **domainO;         // domain of ordering variables
        int *domainSizeD;      // domain size of depth variables
        int **domainD;         // domain of depth variables

        /*
         *  Current domain sizes and last valid domain element,
         *  maintained during search.
         */
        int *domainSizeCurrentP;
        int *domainSizeCurrentO;
        int *domainSizeCurrentD;
        int *lastValidP;
#else
        int domainSizeP[MAX_VARS];      // domain size of parent variables
        Value *domainP[MAX_VARS];       // domain of parent variables
        int domainSizeO[MAX_VARS];      // domain size of ordering variables
        int *domainO[MAX_VARS];         // domain of ordering variables
        int domainSizeD[MAX_VARS];      // domain size of depth variables
        int *domainD[MAX_VARS];         // domain of depth variables

        /*
         *  Current domain sizes and last valid domain element,
         *  maintained during search.
         */
        int domainSizeCurrentP[MAX_VARS];
        int domainSizeCurrentO[MAX_VARS];
        int domainSizeCurrentD[MAX_VARS];
        int lastValidP[MAX_VARS];
#endif
        /* Consdensed view of P domains, updated lazily during iteration */
        std::vector<std::vector<int>> condensedDomainP;
        std::vector<uint8_t> needsResetP;

        /* Does the condensed representation contain some deleted values? */
        bool dirtyP(int v) const;

        /*
         *  Determine set of necessary parents of vertices.
         *
         *  A vertex v is a necessary parent of vertex w if v occurs
         *  in every currently valid parent set for variable w.
         */
#ifdef DYNSET
        Set *necessaryParents;
#else
        Set necessaryParents[MAX_VARS];
#endif
};

#endif // _INSTANCE_H_
