#ifndef _TIMER_H_
#define _TIMER_H_

class Timer
{
    public:
	Timer();
	~Timer();

	void    start();
	double  elapsedTime();

    private:
	double t;
};

#endif // _TIMER_H_
